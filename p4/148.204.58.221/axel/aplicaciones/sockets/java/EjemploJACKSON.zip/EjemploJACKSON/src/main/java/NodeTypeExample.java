import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeType;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NodeTypeExample {
    public static void main(String[] args) throws Exception {
        String json = "{\"name\":\"Jake\", \"salary\":3000, \"isProgrammer\":true}";
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode rootNode = objectMapper.readTree(json);

        // Get the node type of the root (which is an object)
        JsonNodeType rootType = rootNode.getNodeType();
        System.out.println("Root Node Type: " + rootType); // Output: Root Node Type: OBJECT

        // Get the node type of a child field
        JsonNode nameNode = rootNode.get("name");
        JsonNodeType nameType = nameNode.getNodeType();
        System.out.println("Name Node Type: " + nameType); // Output: Name Node Type: STRING
        
        JsonNode salaryNode = rootNode.get("salary");
        JsonNodeType salaryType = salaryNode.getNodeType();
        System.out.println("Salary Node Type: " + salaryType); // Output: Salary Node Type: NUMBER
        
        JsonNode booleanNode = rootNode.get("isProgrammer");
        JsonNodeType booleanType = booleanNode.getNodeType();
        System.out.println("Boolean Node Type: " + booleanType); // Output: Boolean Node Type: BOOLEAN
    }
}
