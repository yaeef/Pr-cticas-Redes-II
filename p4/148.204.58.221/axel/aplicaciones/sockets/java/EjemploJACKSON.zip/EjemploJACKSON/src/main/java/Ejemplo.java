import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.Iterator;

public class Ejemplo {
    
    private static final ObjectMapper objectMapper = new ObjectMapper();
    
    public static String generarJSON() {
        try {
            // Crear el nodo raíz del objeto JSON
            ObjectNode objetoJson = objectMapper.createObjectNode();
            
            // Agregar propiedades simples
            objetoJson.put("nombre", "Daniel");
            objetoJson.put("edad", 30);
            
            // Crear el array de lenguajes de programación
            ArrayNode lenguajesArray = objectMapper.createArrayNode();
            lenguajesArray.add("Java");
            lenguajesArray.add("C");
            lenguajesArray.add("C++");
            lenguajesArray.add("Python");
            
            // Agregar el array al objeto principal
            objetoJson.set("lenguajes", lenguajesArray);
            
            // Convertir a String JSON
            return objectMapper.writeValueAsString(objetoJson);
            
        } catch (Exception e) {
            e.printStackTrace();
            return "{}";
        }
    }
    
    
    public static void decodificarYMostrarJSON(String jsonString) {
        try {
            System.out.println("=== DECODIFICANDO JSON ===");
            System.out.println("JSON recibido: " + jsonString);
            System.out.println();
            
            //parse
            JsonNode jsonNode = objectMapper.readTree(jsonString);
            
            String nombre = jsonNode.get("nombre").asText();
            int edad = jsonNode.get("edad").asInt();
            
            System.out.println("Valores decodificados:");
            System.out.println("Nombre: " + nombre);
            System.out.println("Edad: " + edad);

            //Iterator <JsonNode> it = jsonNode.elements();
            JsonNode lenguajesNode = jsonNode.get("lenguajes");
            if (lenguajesNode != null && lenguajesNode.isArray()) {
                System.out.println("Lenguajes de programacion:");
                //lenguajesNode.isInt())
                // Forma 1: Usando iterador
                Iterator<JsonNode> iterador = lenguajesNode.iterator();
                int contador = 1;
                while (iterador.hasNext()) {
                    JsonNode lenguaje = iterador.next();
                    System.out.println("  " + contador + ". " + lenguaje.asText());
                    contador++;
                }
                
                // Forma 2: También se puede hacer con un for tradicional
                // for (int i = 0; i < lenguajesNode.size(); i++) {
                //     System.out.println("  " + (i+1) + ". " + lenguajesNode.get(i).asText());
                // }
            }
            
            System.out.println("==========================");
            
        } catch (Exception e) {
            System.err.println("Error al decodificar el JSON:");
            e.printStackTrace();
        }
    }
    
    /**
     * Método main para probar la funcionalidad
     */
    public static void main(String[] args) {
        // Llamar al primer método para generar el JSON
        String jsonGenerado = generarJSON();
        
        // Mostrar el JSON generado
        System.out.println("JSON generado: " + jsonGenerado);
        System.out.println();
        
        // Llamar al segundo método para decodificar y mostrar
        decodificarYMostrarJSON(jsonGenerado);
    }
}