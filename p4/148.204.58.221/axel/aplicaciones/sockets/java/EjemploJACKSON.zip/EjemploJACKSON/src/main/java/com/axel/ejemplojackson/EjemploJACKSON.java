
package com.axel.ejemplojackson;

/**
 *
 * @author Axel Ernesto
 */
public class EjemploJACKSON {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
