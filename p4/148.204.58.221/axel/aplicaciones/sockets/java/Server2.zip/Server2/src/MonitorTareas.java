import java.util.concurrent.*;

class Tarea implements Runnable{
    int id;
    public Tarea(int id){
        this.id = id;
    }//Tarea
    
    public void run(){
      try {
           Thread.sleep(1000);
           System.out.println("Tarea " + id + " completada");
           } catch (InterruptedException e) {
             Thread.currentThread().interrupt();
          }//catch        
    }//run
}//class

public class MonitorTareas {
        
    public static void main(String[] args) {
    
       ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(4);
        
        // Encolar algunas tareas
       for (int i = 0; i < 10; i++) {
            int taskId = i;
           executor.submit(new Tarea(i));
       }//for
       
     // Monitorear el estado del pool
        monitorExecutor(executor); 
        executor.shutdown();
    }//main  
    
       public static void monitorExecutor(ThreadPoolExecutor executor)  {     
             System.out.println("Tareas en cola: " + executor.getQueue().size());
             System.out.println("Tareas activas: " + executor.getActiveCount());
             System.out.println("Tareas completadas: " + executor.getCompletedTaskCount());
             System.out.println("Tareas totales programadas: " + executor.getTaskCount());
             System.out.println("Tam maximo de la cola: " + executor.getQueue().remainingCapacity()); /* cantidad de elementos adicionales que esta cola puede aceptar, o Integer.MAX_VALUEsi no hay un límite intrínseco */
    }//monitorExecutor
 
}//class