/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.axel.ejjsonsimple;

/**
 *
 * @author Axel Ernesto
 */
public class EjJsonSimple {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
