import java.io.*;
import java.net.*;
import java.util.Collections;
import java.util.Enumeration;


/**
 *
 * @author axel
 */
public class CHMM1 {

    static void despliegaInfoNIC(NetworkInterface netint) throws SocketException {
        System.out.printf("Nombre de despliegue: %s\n", netint.getDisplayName());
        System.out.printf("Nombre: %s\n", netint.getName());
        String multicast = (netint.supportsMulticast())?"Soporta multicast":"No soporta multicast";
        System.out.printf("Multicast: %s\n", multicast);
        Enumeration<InetAddress> inetAddresses = netint.getInetAddresses();
        for (InetAddress inetAddress : Collections.list(inetAddresses)) {
            System.out.printf("Direccion: %s\n", inetAddress);
        }
        System.out.printf("\n");
     }

    
    public static void main(String[] args){
      try{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
        int z=0,pto= 9931;
        /*
          for (NetworkInterface netint : Collections.list(nets)){
              System.out.print("[Interfaz "+ ++z +"]:");
             despliegaInfoNIC(netint);
          }//for
        System.out.print("\nElige la interfaz multicast:");
        String interfaz = br.readLine();
        //int interfaz = Integer.parseInt(br.readLine());
        NetworkInterface ni = NetworkInterface.getByName(interfaz);
        //NetworkInterface ni = NetworkInterface.getByIndex(interfaz);
        */
         NetworkInterface ni = null;
          for (NetworkInterface netint : Collections.list(nets)){
              System.out.print("[Interfaz "+ ++z +"]:");
              if(!netint.isLoopback() && netint.supportsMulticast() && !netint.isVirtual() && netint.isUp()){
                  System.out.println("posible interfaz: "+netint.getName());
                  Enumeration<InetAddress> inetAddresses = netint.getInetAddresses();
                  if(inetAddresses.hasMoreElements()){
                      ni = NetworkInterface.getByName(netint.getName());
                      break;
                  }else {continue;}
              } else {
                  System.out.println("interfaz descartada: "+netint.getName());
              }//else
              
          }//for
        br.close();
        System.out.println("\nElegiste "+ni.getDisplayName());

         //InetAddress mcastaddr = InetAddress.getByName("230.1.1.2");
         InetAddress mcastaddr = InetAddress.getByName("ff3e:40:2001::1");
         InetSocketAddress gpo = new InetSocketAddress(mcastaddr, pto);
          MulticastSocket cl = new MulticastSocket(pto);
          cl.setReuseAddress(true);
          //cl.setOption(StandardSocketOptions.IP_MULTICAST_LOOP, true);
          System.out.println("Modo multicast habilitado:"+cl.getOption(StandardSocketOptions.IP_MULTICAST_LOOP));
          //InetAddress gpo = InetAddress.getByName("230.1.1.2");
    
          //InetAddress gpo = InetAddress.getByName("ff3e:40:2001::1");
                    
          cl.joinGroup(gpo, ni);
          //cl.joinGroup(mcastaddr);
          System.out.println("Servicio iniciado y unido al grupo.. comienza escucha de mensajes");
          for(;;){
              DatagramPacket p = new DatagramPacket(new byte[65535],65535);
              cl.receive(p);
              System.out.println("Datagrama multicast recibido desde "+p.getAddress()+":"+p.getPort()+"Con el mensaje:"+new String(p.getData(),0,p.getLength()));
              
              
              
          }//for
          
                  
      }catch(Exception e){
          e.printStackTrace();
      }
  }    
}
