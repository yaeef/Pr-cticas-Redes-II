import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.*;
import java.util.Collections;  //interfaz
import java.util.Enumeration;  //clase
//import java.io.*;

/**
 *
 * @author axel
 */
public class SHMM1 {
    
    static void despliegaInfoNIC(NetworkInterface netint) throws SocketException {
        System.out.printf("Nombre de despliegue: %s\n", netint.getDisplayName());
        System.out.printf("Nombre: %s\n", netint.getName());
        String multicast = (netint.supportsMulticast())?"Soporta multicast":"No soporta multicast";
        System.out.printf("Multicast: %s\n", multicast);
        Enumeration<InetAddress> inetAddresses = netint.getInetAddresses();
        for (InetAddress inetAddress : Collections.list(inetAddresses)) {
            System.out.printf("Direccion: %s\n", inetAddress);
        }
        System.out.printf("\n");
     }


    public static void main(String[] args){
    try{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
        int z=0,pto= 9930,pto_dst=9931;  //////////
        
        /*  for (NetworkInterface netint : Collections.list(nets)){
              System.out.print("[Interfaz "+ ++z +"]:");
             despliegaInfoNIC(netint);
          }//for
        */
        String emoji = "😄"; // Pega el emoji aquí directamente
        PrintWriter pw1 = new PrintWriter(new OutputStreamWriter(System.out,"UTF-8"));
        pw1.printf("%s\n",emoji);
        pw1.flush();
        // Para un emoji con un surrogate pair, como el cohete (U+1F680)
        pw1.printf("\uD83D\uDE80 \n");
        pw1.flush();
        
         NetworkInterface ni = null;
 
          for (NetworkInterface netint : Collections.list(nets)){
              System.out.print("[Interfaz "+ ++z +"]:");
              if(!netint.isLoopback() && netint.supportsMulticast() && !netint.isVirtual() && netint.isUp()){
                  System.out.println("posible interfaz: "+netint.getName());
                  Enumeration<InetAddress> inetAddresses = netint.getInetAddresses();
                  if(inetAddresses.hasMoreElements()){
                      ni = NetworkInterface.getByName(netint.getName());
                      break;
                  }else {continue;}
              } else {
                  System.out.println("interfaz descartada: "+netint.getName());
              }//else
              
          }//for
        br.close();
        System.out.println("\nElegiste "+ni.getDisplayName());
        
        ///////////////////////////
         //InetAddress mcastaddr = InetAddress.getByName("230.1.1.2");
         InetAddress mcastaddr = InetAddress.getByName("ff3e:40:2001::1");
         InetSocketAddress gpo = new InetSocketAddress(mcastaddr, pto);
         
         MulticastSocket s = new MulticastSocket(pto);
         //s.setOption(StandardSocketOptions.IP_MULTICAST_LOOP, true);
         s.joinGroup(gpo, ni);
         //s.joinGroup(mcastaddr);
        ///////////////////////////
        
            String msj="servidor       1.."; /**/
            byte[] b = msj.getBytes();
            System.out.println("Servicio iniciado.. comienza envio de anuncios");
            for(;;){
              DatagramPacket p = new DatagramPacket(b,b.length,mcastaddr,pto_dst);
              s.send(p);
                System.out.println("Mensaje enviado con un ttl="+s.getTimeToLive());
              try{
                  Thread.sleep(5000);
              }catch(InterruptedException ie){}
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//main
}
